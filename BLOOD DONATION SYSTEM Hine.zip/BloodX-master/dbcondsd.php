<html><head></head>
<body>
<section id="main">


      <form action="org\dash2.php" method="post" id="msform">
          
          <input type="submit" name="submit" value="submit"/>
          </form>
          </section>
          </body>
          </html>