<?php

	$con = mysqli_connect('localhost','root','','osp');

	if($con == false){
		echo "Connection not successful";
	}
	
?>