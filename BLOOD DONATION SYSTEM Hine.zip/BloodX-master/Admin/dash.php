<html>
    options:
    1. all users
    2. all organizations
    3. all sponsors
    4. money left for sponsoring events
    5 request of sponsors
    6. urgent requests of blood
    7. blood availability
</html>
