<html> 
    options:
    1. check the current requests
</html>